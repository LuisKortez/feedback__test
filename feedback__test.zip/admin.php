<?php 
include_once "dbclass.php";

$db = new DBClass(SERVER,USER,PASS,DBNAME);

if (!empty($_POST['review_id']) && !empty($_POST['actions']) && !empty($_POST['submit'])){
  $db->do_change_review($_POST['review_id'], $_POST['actions'] );
}

$testimonials =  $db->select_all();

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link rel="stylesheet" href="/assets/style.css" crossorigin="anonymous">
    <title>Admin feedback</title>
  </head>
  <body>
<div class="container">
<div class="row">
<div class="col-md-12">
<h1>Admin Panel</h1>
</div>
</div>
 
<div class="navbar navbar-default row the_title">

 <div class="col-md-1">Product</div>
 <div class="col-md-1">name</div>
 <div class="col-md-3">description</div>
 <div class="col-md-2">email</div>
 <div class="col-md-1">image</div>
 <div class="col-md-1">status</div>
 <div class="col-md-3">actions</div>
 
 </div>

<?php foreach($testimonials as $testimonial): ?>
 <div class="row gap" data-review="<?php echo $testimonial['review_id']; ?>">
 <div class="col-md-1"><?php echo $testimonial['product_name']; ?></div>
 <div class="col-md-1"><?php echo $testimonial['firstname']; ?></div>
 <div class="col-md-3"><?php echo $testimonial['description']; ?></div>
 <div class="col-md-2"><?php echo $testimonial['email']; ?></div>
 <div class="col-md-1"><img class="img-responsive" src="/uploads/<?php echo $testimonial['thumb']; ?>" alt=""></div>
 <div class="col-md-1"><?php echo $testimonial['status']; ?></div>
<div class="col-md-3">
 <?php if(($testimonial['status'] == 'rejected') || ($testimonial['status'] == 'disput') ){ ?>
  <button class="btn btn-success">Approve</button>
 <?php } ?>
 <?php if(($testimonial['status'] == 'public') || ($testimonial['status'] == 'disput') ){ ?>
  <button class="btn btn-warning">Reject</button>
 <?php } ?>
<button class="btn btn-danger">Delete</button>
</div> 

 </div>
<?php endforeach; ?>
 </div>

<footer class="container">
  <div class="row">
    <div class="col-12 col-md">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="d-block mb-2" focusable="false" role="img"><title>Product</title><circle cx="12" cy="12" r="10"></circle><line x1="14.31" y1="8" x2="20.05" y2="17.94"></line><line x1="9.69" y1="8" x2="21.17" y2="8"></line><line x1="7.38" y1="12" x2="13.12" y2="2.06"></line><line x1="9.69" y1="16" x2="3.95" y2="6.06"></line><line x1="14.31" y1="16" x2="2.83" y2="16"></line><line x1="16.62" y1="12" x2="10.88" y2="21.94"></line></svg>
      <small class="d-block mb-3 text-muted">© 2019</small>
    </div>
  </div>
</footer>
<form id="review__actions" action="" method="POST">
<input type="hidden" name="review_id">
<input type="hidden" name="actions">
<input name="submit"  type="submit" style="display:none;">
</form>
<script src="/assets/jquery.js"></script>   
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script>
function change_status_review(el, status){
  var review_id = el.closest('.row').data('review');
  jQuery('#review__actions').find("[name='review_id']").val(review_id);
  jQuery('#review__actions').find("[name='actions']").val(status);
  jQuery('#review__actions input[type="submit"]').trigger('click');
}



$(document).ready(function(e){
   jQuery('.btn').on('click', function(){

    if(confirm('Are you sure ?')){
  if (jQuery(this).hasClass('btn-success')){
      change_status_review(jQuery(this), 'public');
  } 
  if (jQuery(this).hasClass('btn-warning')){
     change_status_review(jQuery(this), 'disput');
  } 
  if (jQuery(this).hasClass('btn-danger')){
     change_status_review(jQuery(this), 'delete');
  } 
}
});

});
</script>

  </body>
</html>