<?php 
define('SERVER','localhost');
define('USER','root');
define('PASS','');
define('DBNAME','feedbacks');