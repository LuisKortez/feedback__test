<?php

include_once "config.php";

$email = "'" . $_POST['email'] . "'";;
$product_id =  $_POST['product_id'];
$firstname ="'" . $_POST['firstname']. "'";
$description ="'" . $_POST['text']. "'";

$status="'" .'disput'. "'";


if(!empty($_POST['firstname']) || !empty($_POST['email']) || !empty($_FILES['file']['name'])){
    $uploadedFile = '';
    if(!empty($_FILES["file"]["type"])){
        $fileName = date('y-m-d').'_'.$_FILES['file']['name'];
        $valid_extensions = array("jpeg", "jpg", "png");
        $temporary = explode(".", $_FILES["file"]["name"]);
        $file_extension = end($temporary);
        if((($_FILES["hard_file"]["type"] == "image/png") || ($_FILES["file"]["type"] == "image/jpg") || ($_FILES["file"]["type"] == "image/jpeg")) && in_array($file_extension, $valid_extensions)){
            $sourcePath = $_FILES['file']['tmp_name'];
            $targetPath = "uploads/".$fileName;
            if(move_uploaded_file($sourcePath,$targetPath)){
                $uploadedFile = $fileName;
            }
        }
    }
}

$img ="'" . $fileName . "'";

	// Create connection
$conn = new mysqli(SERVER, USER, PASS, DBNAME);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO testimonials (product_id, firstname, email, description, img, status )
VALUES ( $product_id , $firstname, $email, $description, $img, $status)";

if ($conn->query($sql) === TRUE) {
    echo 'ok';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();