<?php

include_once "config.php";

class DBCLass
  {
 
public function select($product_id)
 { 

$conn = new mysqli(SERVER, USER, PASS, DBNAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `testimonials` WHERE `product_id` = " . $product_id . " AND `status` = 'public'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $testimonials = array();
    while($row = $result->fetch_assoc()) {
        $testimonials[] = array(
            'product_id'  => $row['product_id'],
            'thumb'       => $row['img'],
            'firstname'   => $row['firstname'],
            'description' => strip_tags(html_entity_decode($row['description'], ENT_QUOTES, 'UTF-8')),    
   );
    }
    return  $testimonials;
} else {
    return false;
}
$conn->close();
 }

 public function select_all()
 { 

$conn = new mysqli(SERVER, USER, PASS, DBNAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `testimonials` AS t LEFT JOIN `products` AS p ON p.ID = t.product_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $testimonials = array();
    while($row = $result->fetch_assoc()) {
        $testimonials[] = array(
            'product_name'=> $row['name'],
            'product_id'  => $row['product_id'],
            'review_id'   => $row['review_ID'],
            'thumb'       => $row['img'],
            'email'       => $row['email'],
            'status'      => $row['status'],
            'firstname'   => $row['firstname'],
            'description' => strip_tags(html_entity_decode($row['description'], ENT_QUOTES, 'UTF-8')),    
   );
    }
    return  $testimonials;
} else {
    return false;
}
$conn->close();
 }

 public function do_change_review($review_id, $actions)
 { 

$conn = new mysqli(SERVER, USER, PASS, DBNAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


if ($actions == 'delete'){
    $sql = "DELETE FROM `testimonials` WHERE `review_id`='" . $review_id . "'";
}

if ($actions == 'public'){
    $sql = "UPDATE `testimonials` SET `status` = 'public' WHERE `review_id`='" . $review_id . "'";
}

if ($actions == 'disput'){
    $sql = "UPDATE `testimonials` SET `status` = 'rejected' WHERE `review_id`='" . $review_id. "'";
}


$result = $conn->query($sql);
$conn->close();
 }


}