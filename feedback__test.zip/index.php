<?php 

include_once "dbclass.php";

$db = new DBClass(SERVER,USER,PASS,DBNAME);
$product_id = $_GET['product_id'];
$testimonials =  $db->select($product_id);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
   <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link rel="stylesheet" href="/assets/style.css" crossorigin="anonymous">

    <title>feedback__test</title>
  </head>
  <body>
<div class="container">
  <div class="row gap">
  <div class="col-md-6">
      <h2>xiaomi</h2>
      <p>phone for you</p>
    <img class="img-responsive" src="/assets/xiaomi_redmi_note5.jpg" alt="xiaomi_redmi_note5">  
    </div>
  <div class="col-md-6">
  <p class="lead">Tetsimonials</p>


<?php if($testimonials):
   foreach($testimonials as $testimonial): ?>

<div class="row text-left gap">
    <div class="col-md-3">
<img src="/uploads/<?php  echo  $testimonial['thumb']; ?>" class="img-responsive">
    </div>
    <div class="col-md-9">
        <div class="name gap"><?php  echo  $testimonial['firstname']; ?></div>
        <p><?php  echo  $testimonial['description']; ?></p>
    </div>
</div>
<?php endforeach; endif;?>
<div class="row">
<div class="col-md-12">
<hr class="gap">
<h3>Leave comment</h2>

<form enctype="multipart/form-data" method="post" action="review.php"> 
<input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input required name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputname">Name</label>
    <input name="firstname" type="text" class="form-control alphaonly" id="exampleInputname" placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Photo</label>
    <input name="file" type="file" class="form-control-file" id="fileImg">
  </div>
  <div class="form-group">
    <textarea  class="form-control" required name="text"></textarea>
  </div>

  <button type="submit" id="tosubmit" class="btn btn-primary">Submit</button>
</form>
<div class="statusMsg"></div>
</div>

</div>
</div>
</div>

<footer class="container">
  <div class="row">
    <div class="col-12 col-md">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="d-block mb-2" focusable="false" role="img"><title>Product</title><circle cx="12" cy="12" r="10"></circle><line x1="14.31" y1="8" x2="20.05" y2="17.94"></line><line x1="9.69" y1="8" x2="21.17" y2="8"></line><line x1="7.38" y1="12" x2="13.12" y2="2.06"></line><line x1="9.69" y1="16" x2="3.95" y2="6.06"></line><line x1="14.31" y1="16" x2="2.83" y2="16"></line><line x1="16.62" y1="12" x2="10.88" y2="21.94"></line></svg>
      <small class="d-block mb-3 text-muted">© 2019</small>
    </div>
  </div>
</footer>

<script src="/assets/jquery.js"></script>   
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<script>
$(document).ready(function(e){
    $("form").on('submit', function(e){
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'review.php',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                $('#tosubmit').attr("disabled","disabled");
                $('form').css("opacity",".5");
            },
            success: function(msg){
                $('.statusMsg').html('');
                if(msg == 'ok'){
                    $('form')[0].reset();
                    $('.statusMsg').html('<span style="font-size:18px;color:#34A853">Form data submitted successfully.</span>');
                }else{
                    $('.statusMsg').html('<span style="font-size:18px;color:#EA4335">Some problem occurred, please try again.</span>');
                }
                $('form').css("opacity","");
                $("#tosubmit").removeAttr("disabled");
            }
        });
    });
    
    //file type validation
    $("#fileImg").change(function() {
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2]))){
            alert('Please select a valid image file (JPEG/JPG/PNG).');
            $("#fileImg").val('');
            return false;
        }
    });

    $('.alphaonly').bind('keyup blur',function(){ 
    var node = $(this);
    node.val(node.val().replace(/[^a-z]/g,'') );}
);
});
</script>

  </body>
</html>